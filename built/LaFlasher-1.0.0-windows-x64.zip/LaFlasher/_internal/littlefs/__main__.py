import argparse
from contextlib import suppress
import os
from pathlib import Path
import sys
import textwrap

from littlefs import LittleFS, __version__
from littlefs.errors import LittleFSError
from littlefs.repl import LittleFSRepl
from littlefs.context import UserContextFile, UserContext

# Dictionary mapping suffixes to their size in bytes
_suffix_map = {
    "kb": 1024,
    "mb": 1024**2,
    "gb": 1024**3,
}


def _fs_from_args(args: argparse.Namespace, block_count=None, mount=True, context: UserContext = None) -> LittleFS:
    """Build LittleFS from CLI args. Options name_max, attr_max, file_max are stored in the
    superblock and must match when mounting an existing image. inline_max is format-relevant
    (limiting it may improve flash usage)."""
    block_count = block_count if block_count is not None else getattr(args, "block_count", 0)
    kwargs = {
        "block_size": args.block_size,
        "block_count": block_count,
        "name_max": args.name_max,
        "inline_max": args.inline_max,
        "attr_max": args.attr_max,
        "file_max": args.file_max,
        "filename_encoding": getattr(args, "filename_encoding", None),
    }
    return LittleFS(context=context, mount=mount, **kwargs)


def size_parser(size_str):
    """Parse filesystem / block size in different formats"""
    size_str = str(size_str).lower()

    # Check if the string starts with '0x', which indicates a hexadecimal number
    if size_str.startswith("0x"):
        base = 16
        size_str = size_str[2:]
    else:
        base = 10

    # Separate the size number and suffix
    for suffix, multiplier in _suffix_map.items():
        if size_str.endswith(suffix):
            num_part = size_str[: -len(suffix)]
            return int(num_part, base) * multiplier

    # Handle base units; remove base suffix
    if size_str.endswith("b"):
        size_str = size_str[:-1]

    # If no suffix, assume it's in bytes
    return int(size_str, base)


def _walk_all(root):
    """Recursively yield all paths under root, following symlinks."""
    for dirpath, dirnames, filenames in os.walk(root, followlinks=True):
        dirpath = Path(dirpath)
        for dirname in dirnames:
            yield dirpath / dirname
        for filename in filenames:
            yield dirpath / filename


def create(parser: argparse.ArgumentParser, args: argparse.Namespace) -> int:
    """Create LittleFS image from file/directory contents."""
    # fs_size OR block_count may be populated; make them consistent.
    if args.block_count is None:
        block_count = args.fs_size // args.block_size
        if block_count * args.block_size != args.fs_size:
            parser.error("fs-size must be a multiple of block-size.")
        args.block_count = block_count
    else:
        args.fs_size = args.block_size * args.block_count

    if args.verbose:
        print("LittleFS Configuration:")
        print(f"  Block Size:  {args.block_size:9d}  /  0x{args.block_size:X}")
        print(f"  Image Size:  {args.fs_size:9d}  /  0x{args.fs_size:X}")
        print(f"  Block Count: {args.block_count:9d}")
        print(f"  Name Max:    {args.name_max:9d}")
        if args.inline_max:
            print(f"  Inline Max:  {args.inline_max:9d}  /  0x{args.inline_max:X}")
        if args.attr_max:
            print(f"  Attr Max:    {args.attr_max:9d}")
        if args.file_max:
            print(f"  File Max:    {args.file_max:9d}")
        print(f"  Image:       {args.destination}")

    source = Path(args.source).absolute()
    if source.is_dir():
        sources = list(_walk_all(source))
        root = source
    else:
        sources = [source]
        root = source.parent

    fs = _fs_from_args(args)
    for path in sources:
        rel_path = path.relative_to(root)
        if path.is_dir():
            if args.verbose:
                print("Adding Directory:", rel_path)
            fs.mkdir(rel_path.as_posix())
        else:
            if args.verbose:
                print("Adding File:     ", rel_path)
            with fs.open(rel_path.as_posix(), "wb") as dest:
                dest.write(path.read_bytes())

    if args.compact:
        if args.verbose:
            print(f"Compacting... {fs.used_block_count} / {args.block_count}")
        compact_fs = _fs_from_args(args, block_count=fs.used_block_count)
        for path in sources:
            rel_path = path.relative_to(root)
            if path.is_dir():
                compact_fs.mkdir(rel_path.as_posix())
            else:
                with compact_fs.open(rel_path.as_posix(), "wb") as dest:
                    dest.write(path.read_bytes())
        compact_fs.fs_grow(args.block_count)
        data = compact_fs.context.buffer
        if not args.no_pad:
            data = data.ljust(args.fs_size, b"\xff")
    else:
        data = fs.context.buffer

    args.destination.parent.mkdir(exist_ok=True, parents=True)
    args.destination.write_bytes(data)
    return 0


def _mount_from_context(parser: argparse.ArgumentParser, args: argparse.Namespace, context: UserContext) -> LittleFS:
    # Block count is 0 because we don't know the size of the real image yet, the source file may be compacted (with the create --compact option).
    fs = _fs_from_args(args, block_count=0, mount=False, context=context)
    fs.mount()

    if args.verbose:
        input_image_size = context.in_size
        actual_image_size = fs.block_count * args.block_size
        print("LittleFS Configuration:")
        print(f"  Block Size:  {args.block_size:9d}  /  0x{args.block_size:X}")
        if input_image_size != actual_image_size:
            print(f"  Image Size:  {actual_image_size:9d}  /  0x{actual_image_size:X}")
            print(f"  Input Image Size (compacted): {input_image_size:9d}  /  0x{input_image_size:X}")
        else:
            print(f"  Image Size:  {input_image_size:9d}  /  0x{input_image_size:X}")
        print(f"  Block Count: {fs.block_count:9d}")
        print(f"  Name Max:    {args.name_max:9d}")
        if args.inline_max:
            print(f"  Inline Max:  {args.inline_max:9d}  /  0x{args.inline_max:X}")
        if args.attr_max:
            print(f"  Attr Max:    {args.attr_max:9d}")
        if args.file_max:
            print(f"  File Max:    {args.file_max:9d}")
        print(f"  Image:       {args.source}")

    return fs


def _list(parser: argparse.ArgumentParser, args: argparse.Namespace) -> int:
    """List LittleFS image contents."""
    source: Path = args.source
    if not source.is_file():
        parser.error(f"Source image '{source}' does not exist.")
    context = UserContext(buffer=bytearray(source.read_bytes()))

    fs = _mount_from_context(parser, args, context)

    for root, dirs, files in fs.walk("/"):
        if not root.endswith("/"):
            root += "/"
        for dir in dirs:
            print(f"{root}{dir}")
        for file in files:
            print(f"{root}{file}")
    return 0


def extract(parser: argparse.ArgumentParser, args: argparse.Namespace) -> int:
    """Extract LittleFS image contents to a directory."""
    source: Path = args.source
    if not source.is_file():
        parser.error(f"Source image '{source}' does not exist.")
    context = UserContext(buffer=bytearray(source.read_bytes()))

    fs = _mount_from_context(parser, args, context)

    root_dest = args.destination.absolute()
    if not root_dest.exists():
        root_dest.mkdir(parents=True)
    if not root_dest.is_dir():
        print("Destination must be a directory.")
        return 1

    for root, dirs, files in fs.walk("/"):
        if not root.endswith("/"):
            root += "/"
        for dir in dirs:
            src_path = root + dir
            dst_path = root_dest / src_path[1:]
            if args.verbose:
                print(src_path, dst_path)
            assert root_dest in dst_path.parents
            dst_path.mkdir(exist_ok=True)
        for file in files:
            src_path = root + file
            dst_path = root_dest / src_path[1:]
            if args.verbose:
                print(src_path, dst_path)
            assert root_dest in dst_path.parents
            with fs.open(src_path, "rb") as src:
                dst_path.write_bytes(src.read())

    return 0


def repl(parser: argparse.ArgumentParser, args: argparse.Namespace) -> int:
    """Inspect an existing LittleFS image through an interactive shell."""
    source: Path = args.source
    if not source.is_file():
        parser.error(f"Source image '{source}' does not exist.")
    context = UserContextFile(str(source))  # In repl we want context to be the file itself, so commands will change it

    try:
        try:
            fs = _mount_from_context(parser, args, context)
        except LittleFSError as exc:
            parser.error(f"Failed to mount '{source}': {exc}")

        shell = LittleFSRepl(fs)

        shell.cmdloop()
    finally:
        if shell._mounted:
            with suppress(LittleFSError):
                fs.unmount()

    return 0


def get_parser():
    if sys.argv[0].endswith("__main__.py"):
        prog = f"python -m littlefs"
    else:
        prog = f"littlefs-python"

    parser = argparse.ArgumentParser(
        prog=prog,
        description=textwrap.dedent(
            """\
            Create, extract and inspect LittleFS filesystem images. Use one of the
            commands listed below, the '-h' / '--help' option can be used on each
            command to learn more about the usage.
            """
        ),
        # formatter_class=argparse.RawTextHelpFormatter,
    )
    parser.add_argument("--version", action="version", version=__version__)

    common_parser = argparse.ArgumentParser(add_help=False)
    common_parser.add_argument("-v", "--verbose", action="count", default=0)
    # Stored in superblock; must match when mounting an existing image:
    common_parser.add_argument(
        "--name-max",
        type=size_parser,
        default=255,
        help="LittleFS max file path length. Defaults to LittleFS's default (255).",
    )
    common_parser.add_argument(
        "--attr-max",
        type=int,
        default=0,
        help="Max custom attribute size per file. Defaults to LittleFS's default (0 = use library default).",
    )
    common_parser.add_argument(
        "--file-max",
        type=int,
        default=0,
        help="Max number of open files. Defaults to LittleFS's default (0 = use library default).",
    )
    # Format option: limiting inline_max may improve flash usage.
    common_parser.add_argument(
        "--inline-max",
        type=size_parser,
        default=0,
        help="Max inline file size; 0 = use library default. Limiting can improve flash usage.",
    )
    # Host-side encode/decode choice; never stored in the image. The same encoding
    # must be used to extract an image as was used to create it, otherwise filenames
    # will fail to decode or come out as mojibake.
    common_parser.add_argument(
        "--filename-encoding",
        default=None,
        help="Encoding for filenames stored in the image. Defaults to utf-8. "
        "Use e.g. latin-1 or shift-jis for images whose names use a different encoding.",
    )

    subparsers = parser.add_subparsers(required=True, title="Available Commands", dest="command")

    def add_command(handler, name="", help=""):
        subparser = subparsers.add_parser(
            name or handler.__name__, parents=[common_parser], help=help or handler.__doc__
        )
        subparser.set_defaults(func=handler)
        return subparser

    parser_create = add_command(create)
    parser_create.add_argument(
        "source",
        type=Path,
        help="Source file/directory-of-files to encode into a littlefs filesystem.",
    )
    parser_create.add_argument(
        "destination",
        type=Path,
        nargs="?",
        default=Path("lfs.bin"),
        help="Output LittleFS filesystem binary image.",
    )
    parser_create.add_argument(
        "--block-size",
        type=size_parser,
        required=True,
        help="LittleFS block size.",
    )
    parser_create.add_argument(
        "--compact",
        action="store_true",
        help="Store all data in the beginning blocks.",
    )
    parser_create.add_argument(
        "--no-pad",
        action="store_true",
        help="Do not pad the binary to-size with 0xFF. Only valid with --compact.",
    )
    block_count_group = parser_create.add_mutually_exclusive_group(required=True)
    block_count_group.add_argument(
        "--block-count",
        type=int,
        help="LittleFS block count",
    )
    block_count_group.add_argument(
        "--fs-size",
        type=size_parser,
        help="LittleFS filesystem size. Accepts byte units; e.g. 1MB and 1048576 are equivalent.",
    )

    parser_extract = add_command(extract)
    parser_extract.add_argument(
        "source",
        type=Path,
        help="Source LittleFS filesystem binary.",
    )
    parser_extract.add_argument(
        "destination",
        default=Path("."),
        nargs="?",
        type=Path,
        help="Destination directory. Defaults to current directory.",
    )
    parser_extract.add_argument(
        "--block-size",
        type=size_parser,
        required=True,
        help="LittleFS block size.",
    )

    parser_list = add_command(_list, "list")
    parser_list.add_argument(
        "source",
        type=Path,
        help="Source LittleFS filesystem binary.",
    )
    parser_list.add_argument(
        "--block-size",
        type=size_parser,
        required=True,
        help="LittleFS block size.",
    )

    parser_repl = add_command(repl)
    parser_repl.add_argument(
        "source",
        type=Path,
        help="Source LittleFS filesystem binary.",
    )
    parser_repl.add_argument(
        "--block-size",
        type=size_parser,
        required=True,
        help="LittleFS block size.",
    )

    return parser


# Getting argv optionally from the caller to enable call from python (generally for testing, but could be used for other purposes)
def main(argv=None):
    if argv is None:
        argv = sys.argv
    parser = get_parser()
    parser.parse_known_args(argv[1:])  # Allows for ``littlefs-python --version``
    args = parser.parse_args(argv[1:])
    return args.func(parser, args)


if __name__ == "__main__":
    sys.exit(main())
